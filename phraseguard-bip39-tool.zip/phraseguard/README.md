# PhraseGuard — BIP39 tool

A static browser-based demo with:
- BIP39 12-word phrase generation using `crypto.getRandomValues`
- English BIP39 word-list and checksum validation
- No phrase submission endpoint or analytics code

## Run locally
For Web Crypto support, serve over localhost rather than opening the file directly:
```bash
python -m http.server 8000
```
Then open http://localhost:8000 in your browser.

## Publish for a shareable link
1. Create a repository on GitHub and upload `index.html` as the repository's `index.html`.
2. Open repository Settings → Pages.
3. Choose deploy from the main branch and root folder.
4. GitHub Pages will provide a public HTTPS link after deployment.

The demo fetches the official BIP39 English word list from the Bitcoin BIPs repository on first use. For a stricter offline deployment, vendor the word list locally and review/audit the source and hosting before using it with any real recovery phrase.

Security: never enter a valuable recovery phrase into a website unless you have reviewed and trust its code and hosting. A valid checksum does not prove wallet existence or balance.
